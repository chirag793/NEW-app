import { createTRPCReact } from "@trpc/react-query";
import { httpLink } from "@trpc/client";
import type { AppRouter } from "@/backend/trpc/app-router";

export const trpc = createTRPCReact<AppRouter>();

const getBaseUrl = () => {
  if (process.env.EXPO_PUBLIC_RORK_API_BASE_URL) {
    return process.env.EXPO_PUBLIC_RORK_API_BASE_URL;
  }

  // Return a dummy URL if not configured to prevent crashes
  console.warn('EXPO_PUBLIC_RORK_API_BASE_URL not configured, tRPC will not work');
  return 'http://localhost:3000';
};

export const trpcClient = trpc.createClient({
  links: [
    httpLink({
      url: `${getBaseUrl()}/api/trpc`,
      fetch: (url, options) => {
        // If base URL is not properly configured, return a mock response
        if (!process.env.EXPO_PUBLIC_RORK_API_BASE_URL) {
          console.warn('tRPC request blocked - API base URL not configured');
          return Promise.resolve(new Response(
            JSON.stringify({ error: 'API not configured' }),
            { status: 500, headers: { 'Content-Type': 'application/json' } }
          ));
        }
        return fetch(url, options);
      },
    }),
  ],
});