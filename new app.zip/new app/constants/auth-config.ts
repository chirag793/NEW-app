{\rtf1\ansi\ansicpg1252\cocoartf2865
\cocoatextscaling1\cocoaplatform1{\fonttbl\f0\fmodern\fcharset0 Courier;\f1\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;\red250\green250\blue250;\red106\green153\blue85;\red197\green134\blue192;
\red86\green156\blue214;\red156\green220\blue254;\red212\green212\blue212;\red206\green145\blue120;}
{\*\expandedcolortbl;;\cssrgb\c98039\c98039\c98039;\cssrgb\c41569\c60000\c33333;\cssrgb\c77255\c52549\c75294;
\cssrgb\c33725\c61176\c83922;\cssrgb\c61176\c86275\c99608;\cssrgb\c83137\c83137\c83137;\cssrgb\c80784\c56863\c47059;}
\deftab720
\pard\pardeftab720\qr\partightenfactor0

\f0\fs24 \cf2 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 2\
3\
4\
5\
6\
7\
8\
9\
10\
11\
12\
13\
14\
15\
16\
17\
18\
19\
20\
21\
22\
23\
24\
25\
26\
27\
28\
29\
30\
31\
32\
33\
34\
35\
36\
37\
38\
39\
40\
41\
42\
43\
44\
45\
46\
47\
48\
49\
50\
51\
52\
53\
54\
\pard\pardeftab720\partightenfactor0

\f1 \cf3 \strokec3 // Google OAuth Configuration\cf2 \strokec2 \
\cf3 \strokec3 // To use real Google Sign-In:\cf2 \strokec2 \
\cf3 \strokec3 // 1. Go to https://console.cloud.google.com/\cf2 \strokec2 \
\cf3 \strokec3 // 2. Create a new project or select existing one\cf2 \strokec2 \
\cf3 \strokec3 // 3. Enable Google+ API\cf2 \strokec2 \
\cf3 \strokec3 // 4. Create OAuth 2.0 credentials for:\cf2 \strokec2 \
\cf3 \strokec3 //    - iOS: com.yourapp.study\cf2 \strokec2 \
\cf3 \strokec3 //    - Android: com.yourapp.study\cf2 \strokec2 \
\cf3 \strokec3 //    - Web: Your web URL\cf2 \strokec2 \
\cf3 \strokec3 // 5. Replace the IDs below with your actual client IDs\cf2 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf4 \strokec4 export\cf2 \strokec2  \cf5 \strokec5 const\cf2 \strokec2  \cf6 \strokec6 GOOGLE_AUTH_CONFIG\cf2 \strokec2  \cf7 \strokec7 =\cf2 \strokec2  \cf7 \strokec7 \{\cf2 \strokec2 \
  \cf3 \strokec3 // For Expo Go development, use these Expo client IDs\cf2 \strokec2 \
  \cf3 \strokec3 // These work with Expo Go app\cf2 \strokec2 \
  \cf6 \strokec6 expoClientId\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 '603386649315-vp4revvrcgrcjme51ebuhbkbspl048l9.apps.googleusercontent.com'\cf7 \strokec7 ,\cf2 \strokec2 \
  \
  \cf3 \strokec3 // For standalone apps, replace with your own client IDs\cf2 \strokec2 \
  \cf6 \strokec6 iosClientId\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 '603386649315-vp4revvrcgrcjme51ebuhbkbspl048l9.apps.googleusercontent.com'\cf7 \strokec7 ,\cf2 \strokec2 \
  \cf6 \strokec6 androidClientId\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 '603386649315-vp4revvrcgrcjme51ebuhbkbspl048l9.apps.googleusercontent.com'\cf7 \strokec7 ,\cf2 \strokec2 \
  \cf6 \strokec6 webClientId\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 '603386649315-vp4revvrcgrcjme51ebuhbkbspl048l9.apps.googleusercontent.com'\cf7 \strokec7 ,\cf2 \strokec2 \
  \
  \cf3 \strokec3 // Set to true to use real Google Sign-In\cf2 \strokec2 \
  \cf3 \strokec3 // Set to false to use demo accounts (for development without Google setup)\cf2 \strokec2 \
  \cf6 \strokec6 useRealGoogleAuth\cf7 \strokec7 :\cf2 \strokec2  \cf5 \strokec5 false\cf7 \strokec7 ,\cf2 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf7 \strokec7 \};\cf2 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf3 \strokec3 // Apple Sign-In Configuration\cf2 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \strokec4 export\cf2 \strokec2  \cf5 \strokec5 const\cf2 \strokec2  \cf6 \strokec6 APPLE_AUTH_CONFIG\cf2 \strokec2  \cf7 \strokec7 =\cf2 \strokec2  \cf7 \strokec7 \{\cf2 \strokec2 \
  \cf3 \strokec3 // Apple Sign-In is automatically configured for iOS\cf2 \strokec2 \
  \cf3 \strokec3 // No additional setup needed for development\cf2 \strokec2 \
  \cf6 \strokec6 enabled\cf7 \strokec7 :\cf2 \strokec2  \cf5 \strokec5 true\cf7 \strokec7 ,\cf2 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf7 \strokec7 \};\cf2 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf3 \strokec3 // Demo accounts for development/testing\cf2 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \strokec4 export\cf2 \strokec2  \cf5 \strokec5 const\cf2 \strokec2  \cf6 \strokec6 DEMO_ACCOUNTS\cf2 \strokec2  \cf7 \strokec7 =\cf2 \strokec2  \cf7 \strokec7 [\cf2 \strokec2 \
  \cf7 \strokec7 \{\cf2 \strokec2 \
    \cf6 \strokec6 id\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 '1'\cf7 \strokec7 ,\cf2 \strokec2 \
    \cf6 \strokec6 email\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 'student@example.com'\cf7 \strokec7 ,\cf2 \strokec2 \
    \cf6 \strokec6 name\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 'Medical Student'\cf7 \strokec7 ,\cf2 \strokec2 \
    \cf6 \strokec6 photoUrl\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face'\cf7 \strokec7 ,\cf2 \strokec2 \
  \cf7 \strokec7 \},\cf2 \strokec2 \
  \cf7 \strokec7 \{\cf2 \strokec2 \
    \cf6 \strokec6 id\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 '2'\cf7 \strokec7 ,\cf2 \strokec2  \
    \cf6 \strokec6 email\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 'doctor@example.com'\cf7 \strokec7 ,\cf2 \strokec2 \
    \cf6 \strokec6 name\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 'Dr. Sarah Wilson'\cf7 \strokec7 ,\cf2 \strokec2 \
    \cf6 \strokec6 photoUrl\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=150&h=150&fit=crop&crop=face'\cf7 \strokec7 ,\cf2 \strokec2 \
  \cf7 \strokec7 \},\cf2 \strokec2 \
  \cf7 \strokec7 \{\cf2 \strokec2 \
    \cf6 \strokec6 id\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 '3'\cf7 \strokec7 ,\cf2 \strokec2 \
    \cf6 \strokec6 email\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 'resident@example.com'\cf7 \strokec7 ,\cf2 \strokec2  \
    \cf6 \strokec6 name\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 'Dr. Alex Kumar'\cf7 \strokec7 ,\cf2 \strokec2 \
    \cf6 \strokec6 photoUrl\cf7 \strokec7 :\cf2 \strokec2  \cf8 \strokec8 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face'\cf7 \strokec7 ,\cf2 \strokec2 \
  \cf7 \strokec7 \},\cf2 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf7 \strokec7 ];\cf2 \strokec2 \
}